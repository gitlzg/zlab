##' @export


allUserFunc=function(){
  return(c("dataRecovTrans", "dataAndInit","metaData",
           "dataSparsCheck","dataInfo","runGlmnet",
           "cvPicasso","runPicasso","groupBetaToFullBeta"))
}
